package com.example.aula0708

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.aula0708.databinding.Activity2Binding

class Activity2 : AppCompatActivity() {

    private lateinit var binding: Activity2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = Activity2Binding.inflate(layoutInflater)
        //criação da variável "view" que receberá a root da activity
        //ou seja, todos os elementos de view presentes dentro dela
        var view = binding.root

        //setamos a view que contem o binding de todos os elementos
        //de interface, como sendo o "content view" da nossa classe
        setContentView(view)

        var message = "Seja bem vind@"

        //  --Maneira antiga de acessar o componente--
        //var txtMessage = findViewById<TextView>(R.id.txtMessage)
        //txtMessage.text = message

        binding.txtMessage.text = message
    }
}