package com.example.aula0708

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var edtName = findViewById<EditText>(R.id.edtName)
        var btnRegister = findViewById<Button>(R.id.btnRegister)
        var btnLogin = findViewById<Button>(R.id.btnLogin)

        //evento de clique do botão
        btnRegister.setOnClickListener {

            if(!edtName.text.isEmpty()){
                var name = edtName.text.toString()

                //mostrar toast com o nome informado

                Toast.makeText(this, "Olá $name", Toast.LENGTH_SHORT).show()

                //limpar edtName
                edtName.text.clear()
            }
            else{
                Toast.makeText(this, "O campo está em branco", Toast.LENGTH_SHORT).show()
            }
        }

        btnLogin.setOnClickListener {
            var intent = Intent(this, Activity2::class.java)

            startActivity(intent)
        }
    }
}